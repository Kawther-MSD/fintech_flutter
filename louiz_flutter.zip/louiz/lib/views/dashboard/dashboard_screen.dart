import 'package:flutter/material.dart';
import 'package:louiz/models/transaction.dart' as transaction_model;
import 'package:provider/provider.dart';
import 'package:louiz/controllers/budget_controller.dart';
import 'package:louiz/controllers/transaction_controller.dart';
import 'package:louiz/utils/localization.dart';
import 'package:louiz/utils/constants.dart';

class DashboardScreen extends StatelessWidget {
  const DashboardScreen({super.key});

  @override
  Widget build(BuildContext context) {
    final budgetCtrl = Provider.of<BudgetController>(context);
    final localizedText = AppLocalizations.of(context);
    
    return Scaffold(
      appBar: AppBar(
        title: Text(localizedText?.translate('dashboard') ?? 'Dashboard'),
      ),
      body: SingleChildScrollView(
        child: Column(
          children: [
            // Budget Summary Card
            if (budgetCtrl.currentBudget != null) _buildBudgetCard(context),
            
            // Recent Transactions
            _buildRecentTransactions(context),
            
            // Category Spending
            if (budgetCtrl.currentBudget != null) _buildCategorySpending(context),
          ],
        ),
      ),
    );
  }

  Widget _buildBudgetCard(BuildContext context) {
    final budgetCtrl = Provider.of<BudgetController>(context);
    final localizedText = AppLocalizations.of(context);
    final budget = budgetCtrl.currentBudget!;
    final remaining = budget.totalAmount - budgetCtrl.totalSpent;
    final progress = budgetCtrl.totalSpent / budget.totalAmount;

    return Card(
      margin: const EdgeInsets.all(16),
      child: Padding(
        padding: const EdgeInsets.all(16),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text(
              localizedText?.translate('current_budget') ?? 'Current Budget',
              style: Theme.of(context).textTheme.titleLarge,
            ),
            const SizedBox(height: 8),
            LinearProgressIndicator(
              value: progress > 1 ? 1 : progress,
              backgroundColor: Colors.grey[200],
              color: progress > 0.8 ? Colors.red : Colors.green,
            ),
            const SizedBox(height: 8),
            Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                Text(
                  '${localizedText?.translate('spent') ?? 'Spent'}: ${budgetCtrl.totalSpent.toStringAsFixed(2)} د.ت',
                ),
                Text(
                  '${localizedText?.translate('remaining') ?? 'Remaining'}: ${remaining.toStringAsFixed(2)} د.ت',
                ),
              ],
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildRecentTransactions(BuildContext context) {
    final transactionCtrl = Provider.of<TransactionController>(context);
    final localizedText = AppLocalizations.of(context);
    
    return Card(
      margin: const EdgeInsets.symmetric(horizontal: 16, vertical: 8),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Padding(
            padding: const EdgeInsets.all(16),
            child: Text(
              localizedText?.translate('recent_transactions') ?? 'Recent Transactions',
              style: Theme.of(context).textTheme.titleLarge,
            ),
          ),
          ...transactionCtrl.recentTransactions.map((transaction) => ListTile(
            leading: Icon(
              transaction.type == transaction_model.TransactionType.expense
                  ? Icons.arrow_downward
                  : Icons.arrow_upward,
              color: transaction.type == transaction_model.TransactionType.expense
                  ? Colors.red
                  : Colors.green,
            ),
            title: Text(transaction.description),
            subtitle: Text(transaction.category),
            trailing: Text('${transaction.amount.toStringAsFixed(2)} د.ت'),
          )),
        ],
      ),
    );
  }

  Widget _buildCategorySpending(BuildContext context) {
    final budgetCtrl = Provider.of<BudgetController>(context);
    final localizedText = AppLocalizations.of(context);
    
    return Card(
      margin: const EdgeInsets.all(16),
      child: Padding(
        padding: const EdgeInsets.all(16),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text(
              localizedText?.translate('category_spending') ?? 'Category Spending',
              style: Theme.of(context).textTheme.titleLarge,
            ),
            const SizedBox(height: 16),
            ...budgetCtrl.categorySpending.entries.map((entry) => Padding(
              padding: const EdgeInsets.only(bottom: 8),
              child: Row(
                children: [
                  Expanded(
                    flex: 2,
                    child: Text(entry.key),
                  ),
                  Expanded(
                    flex: 5,
                    child: LinearProgressIndicator(
                      value: entry.value / budgetCtrl.totalSpent,
                      backgroundColor: Colors.grey[200],
                    ),
                  ),
                  Expanded(
                    flex: 2,
                    child: Text(
                      '${entry.value.toStringAsFixed(2)} د.ت',
                      textAlign: TextAlign.end,
                    ),
                  ),
                ],
              ),
            )),
          ],
        ),
      ),
    );
  }
}