import 'package:flutter/material.dart';
import 'package:intl/intl.dart'; // Add this import
import 'package:provider/provider.dart';
import 'package:louiz/controllers/auth_controller.dart'; // Add this import
import 'package:louiz/controllers/transaction_controller.dart';
import 'package:louiz/controllers/voice_controller.dart';
import 'package:louiz/models/transaction.dart'; // Add this import
import 'package:louiz/utils/constants.dart';
import 'package:louiz/utils/localization.dart';

class AddTransactionDialog extends StatefulWidget {
  const AddTransactionDialog({super.key});

  @override
  _AddTransactionDialogState createState() => _AddTransactionDialogState();
}

class _AddTransactionDialogState extends State<AddTransactionDialog> {
  final _formKey = GlobalKey<FormState>();
  final _amountController = TextEditingController();
  final _descriptionController = TextEditingController();
  
  TransactionType _selectedType = TransactionType.expense;
  String _selectedCategory = AppConstants.expenseCategories.first;
  DateTime _selectedDate = DateTime.now();
  
  bool _isVoiceInput = false;

  @override
  void dispose() {
    _amountController.dispose();
    _descriptionController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final voiceCtrl = Provider.of<VoiceController>(context);
    final localizedText = AppLocalizations.of(context);
    
    return AlertDialog(
      title: Text(localizedText?.translate('add_transaction') ?? 'Add Transaction'),
      content: SingleChildScrollView(
        child: Form(
          key: _formKey,
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              // Toggle between voice and manual input
              Row(
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  Text(localizedText?.translate('input_method') ?? 'Input Method:'),
                  const SizedBox(width: 10),
                  Switch(
                    value: _isVoiceInput,
                    onChanged: (value) async {
                      if (value) {
                        await voiceCtrl.initSpeech();
                      }
                      if (mounted) {
                        setState(() => _isVoiceInput = value);
                      }
                    },
                    activeColor: Theme.of(context).primaryColor,
                  ),
                  Text(_isVoiceInput 
                      ? localizedText?.translate('voice') ?? 'Voice' 
                      : localizedText?.translate('manual') ?? 'Manual'),
                ],
              ),
              
              if (_isVoiceInput) ...[
                // Voice input UI
                const SizedBox(height: 16),
                Text(localizedText?.translate('speak_now') ?? 'Speak now:'),
                const SizedBox(height: 8),
                Container(
                  padding: const EdgeInsets.all(12),
                  decoration: BoxDecoration(
                    border: Border.all(color: Colors.grey),
                    borderRadius: BorderRadius.circular(8),
                  ),
                  child: Text(
                    voiceCtrl.recognizedText.isNotEmpty 
                        ? voiceCtrl.recognizedText 
                        : localizedText?.translate('nothing_recognized') ?? 'Nothing recognized yet',
                    style: const TextStyle(fontSize: 16),
                  ),
                ),
                const SizedBox(height: 16),
                Row(
                  mainAxisAlignment: MainAxisAlignment.center,
                  children: [
                    IconButton(
                      icon: Icon(
                        voiceCtrl.isListening ? Icons.mic_off : Icons.mic,
                        color: voiceCtrl.isListening ? Colors.red : Theme.of(context).primaryColor,
                        size: 36,
                      ),
                      onPressed: () async {
                        if (voiceCtrl.isListening) {
                          await voiceCtrl.stopListening();
                        } else {
                          await voiceCtrl.startListening();
                        }
                      },
                    ),
                    const SizedBox(width: 20),
                    ElevatedButton(
                      onPressed: () async {
                        if (voiceCtrl.recognizedText.isNotEmpty) {
                          await voiceCtrl.processVoiceCommand(voiceCtrl.recognizedText, context);
                          if (mounted) {
                            Navigator.pop(context);
                          }
                        }
                      },
                      child: Text(localizedText?.translate('process') ?? 'Process'),
                    ),
                  ],
                ),
              ] else ...[
                // Manual input UI
                const SizedBox(height: 16),
                DropdownButtonFormField<TransactionType>(
                  value: _selectedType,
                  items: TransactionType.values.map((type) {
                    return DropdownMenuItem<TransactionType>(
                      value: type,
                      child: Text(_getTypeName(type, localizedText)),
                    );
                  }).toList(),
                  onChanged: (value) {
                    if (value != null && mounted) {
                      setState(() {
                        _selectedType = value;
                        _selectedCategory = value == TransactionType.expense
                            ? AppConstants.expenseCategories.first
                            : AppConstants.incomeCategories.first;
                      });
                    }
                  },
                  decoration: InputDecoration(
                    labelText: localizedText?.translate('type') ?? 'Type',
                    border: OutlineInputBorder(),
                  ),
                ),
                const SizedBox(height: 16),
                TextFormField(
                  controller: _amountController,
                  keyboardType: TextInputType.number,
                  decoration: InputDecoration(
                    labelText: localizedText?.translate('amount') ?? 'Amount',
                    prefixText: 'TND ',
                    border: OutlineInputBorder(),
                  ),
                  validator: (value) {
                    if (value == null || value.isEmpty) {
                      return localizedText?.translate('amount_required') ?? 'Amount is required';
                    }
                    if (double.tryParse(value) == null) {
                      return localizedText?.translate('valid_amount') ?? 'Enter a valid amount';
                    }
                    return null;
                  },
                ),
                const SizedBox(height: 16),
                DropdownButtonFormField<String>(
                  value: _selectedCategory,
                  items: (_selectedType == TransactionType.expense
                          ? AppConstants.expenseCategories
                          : AppConstants.incomeCategories)
                      .map((category) {
                    return DropdownMenuItem<String>(
                      value: category,
                      child: Text(category),
                    );
                  }).toList(),
                  onChanged: (value) {
                    if (value != null && mounted) {
                      setState(() => _selectedCategory = value);
                    }
                  },
                  decoration: InputDecoration(
                    labelText: localizedText?.translate('category') ?? 'Category',
                    border: OutlineInputBorder(),
                  ),
                ),
                const SizedBox(height: 16),
                TextFormField(
                  controller: _descriptionController,
                  decoration: InputDecoration(
                    labelText: localizedText?.translate('description') ?? 'Description',
                    border: OutlineInputBorder(),
                  ),
                  maxLines: 2,
                ),
                const SizedBox(height: 16),
                InkWell(
                  onTap: () async {
                    final date = await showDatePicker(
                      context: context,
                      initialDate: _selectedDate,
                      firstDate: DateTime(2020),
                      lastDate: DateTime.now().add(const Duration(days: 365)),
                    );
                    if (date != null && mounted) {
                      setState(() => _selectedDate = date);
                    }
                  },
                  child: InputDecorator(
                    decoration: InputDecoration(
                      labelText: localizedText?.translate('date') ?? 'Date',
                      border: OutlineInputBorder(),
                    ),
                    child: Row(
                      mainAxisAlignment: MainAxisAlignment.spaceBetween,
                      children: [
                        Text(DateFormat.yMd().format(_selectedDate)),
                        const Icon(Icons.calendar_today),
                      ],
                    ),
                  ),
                ),
              ],
            ],
          ),
        ),
      ),
      actions: [
        TextButton(
          onPressed: () => Navigator.pop(context),
          child: Text(localizedText?.translate('cancel') ?? 'Cancel'),
        ),
        if (!_isVoiceInput)
          ElevatedButton(
            onPressed: () async {
              if ((_formKey.currentState?.validate() ?? false) && mounted) {
                final transaction = Transaction(
                  id: DateTime.now().millisecondsSinceEpoch.toString(),
                  userId: Provider.of<AuthController>(context, listen: false).currentUser?.uid ?? '',
                  type: _selectedType,
                  amount: double.parse(_amountController.text),
                  category: _selectedCategory,
                  description: _descriptionController.text,
                  date: _selectedDate,
                );
                
                try {
                  await Provider.of<TransactionController>(context, listen: false)
                      .addTransaction(transaction);
                  if (mounted) {
                    Navigator.pop(context);
                  }
                } catch (e) {
                  if (mounted) {
                    ScaffoldMessenger.of(context).showSnackBar(
                      SnackBar(content: Text('Failed to add transaction: $e')),
                    );
                  }
                }
              }
            },
            child: Text(localizedText?.translate('add') ?? 'Add'),
          ),
      ],
    );
  }

  String _getTypeName(TransactionType type, AppLocalizations? localizedText) {
    switch (type) {
      case TransactionType.expense:
        return localizedText?.translate('expense') ?? 'Expense';
      case TransactionType.income:
        return localizedText?.translate('income') ?? 'Income';
      case TransactionType.savings:
        return localizedText?.translate('savings') ?? 'Savings';
      case TransactionType.debt:
        return localizedText?.translate('debt') ?? 'Debt';
    }
  }
}