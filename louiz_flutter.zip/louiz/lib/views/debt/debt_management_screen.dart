import 'package:flutter/material.dart';
import 'package:intl/intl.dart';
import 'package:louiz/controllers/auth_controller.dart';
import 'package:louiz/views/debt/add_debt_dialog.dart';
import 'package:provider/provider.dart';
import 'package:louiz/controllers/debt_controller.dart';
import 'package:louiz/models/debt.dart';
import 'package:louiz/utils/localization.dart';

class DebtManagementScreen extends StatefulWidget {
  const DebtManagementScreen({super.key});

  @override
  State<DebtManagementScreen> createState() => _DebtManagementScreenState();
}

class _DebtManagementScreenState extends State<DebtManagementScreen> {
  @override
  void initState() {
    super.initState();
    // Load debts when screen initializes
    WidgetsBinding.instance.addPostFrameCallback((_) {
      final authCtrl = Provider.of<AuthController>(context, listen: false);
      if (authCtrl.currentUser != null) {
        Provider.of<DebtController>(context, listen: false)
            .fetchDebts(authCtrl.currentUser!.uid);
      }
    });
  }

  @override
  Widget build(BuildContext context) {
    final debtCtrl = Provider.of<DebtController>(context);
    final localizedText = AppLocalizations.of(context);
    
    return DefaultTabController(
      length: 2,
      child: Scaffold(
        appBar: AppBar(
          title: Text(localizedText?.translate('debts') ?? 'Debts'),
          bottom: TabBar(
            tabs: [
              Tab(text: localizedText?.translate('you_owe') ?? 'You Owe'),
              Tab(text: localizedText?.translate('owed_to_you') ?? 'Owed to You'),
            ],
          ),
        ),
        body: debtCtrl.isLoading
            ? const Center(child: CircularProgressIndicator())
            : TabBarView(
                children: [
                  _buildDebtList(
                    context,
                    debtCtrl.owedDebts,
                    localizedText?.translate('no_debts_owed') ?? 'No debts to pay',
                  ),
                  _buildDebtList(
                    context,
                    debtCtrl.dueDebts,
                    localizedText?.translate('no_debts_due') ?? 'No debts to collect',
                  ),
                ],
              ),
        floatingActionButton: FloatingActionButton(
          onPressed: () => _showAddDebtDialog(context),
          child: const Icon(Icons.add),
        ),
      ),
    );
  }

  void _showAddDebtDialog(BuildContext context) {
    showDialog(
      context: context,
      builder: (context) => const AddDebtDialog(),
    );
  }

  Widget _buildDebtList(BuildContext context, List<Debt> debts, String emptyMessage) {
    if (debts.isEmpty) {
      return Center(
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Icon(
              Icons.money_off,
              size: 64,
              color: Colors.grey[400],
            ),
            const SizedBox(height: 16),
            Text(
              emptyMessage,
              style: Theme.of(context).textTheme.titleMedium,
            ),
          ],
        ),
      );
    }

    return ListView.builder(
      padding: const EdgeInsets.all(16),
      itemCount: debts.length,
      itemBuilder: (context, index) {
        final debt = debts[index];
        final isOverdue = debt.dueDate.isBefore(DateTime.now()) && !debt.isPaid;
        
        return Card(
          margin: const EdgeInsets.only(bottom: 16),
          color: isOverdue ? Colors.red[50] : null,
          child: ListTile(
            leading: Icon(
              debt.isOwed ? Icons.arrow_downward : Icons.arrow_upward,
              color: debt.isOwed ? Colors.red : Colors.green,
            ),
            title: Text(debt.description),
            subtitle: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text('${debt.amount.toStringAsFixed(2)} د.ت'),
                Text(
                  '${DateFormat.yMd().format(debt.dueDate)} - ${isOverdue ? 'Overdue' : debt.isPaid ? 'Paid' : 'Pending'}',
                  style: TextStyle(
                    color: isOverdue ? Colors.red : debt.isPaid ? Colors.green : Colors.grey,
                  ),
                ),
              ],
            ),
            trailing: debt.isPaid
                ? const Chip(
                    label: Text('Paid', style: TextStyle(color: Colors.white)),
                    backgroundColor: Colors.green,
                  )
                : IconButton(
                    icon: const Icon(Icons.check),
                    color: Theme.of(context).primaryColor,
                    onPressed: () {
                      Provider.of<DebtController>(context, listen: false)
                          .updateDebtStatus(debt.id, true);
                    },
                  ),
            onLongPress: () => _showDeleteConfirmation(context, debt),
          ),
        );
      },
    );
  }

  void _showDeleteConfirmation(BuildContext context, Debt debt) {
    showDialog(
      context: context,
      builder: (context) => AlertDialog(
        title: const Text('Delete Debt'),
        content: Text('Are you sure you want to delete "${debt.description}"?'),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(context),
            child: const Text('Cancel'),
          ),
          TextButton(
            onPressed: () {
              Provider.of<DebtController>(context, listen: false)
                  .deleteDebt(debt.id);
              Navigator.pop(context);
            },
            child: const Text('Delete', style: TextStyle(color: Colors.red)),
          ),
        ],
      ),
    );
  }
}