import 'package:flutter/material.dart';
import 'package:intl/intl.dart';
import 'package:provider/provider.dart';
import 'package:louiz/controllers/auth_controller.dart';
import 'package:louiz/controllers/debt_controller.dart';
import 'package:louiz/models/debt.dart';
import 'package:louiz/utils/localization.dart';

class AddDebtDialog extends StatefulWidget {
  const AddDebtDialog({super.key});

  @override
  _AddDebtDialogState createState() => _AddDebtDialogState();
}

class _AddDebtDialogState extends State<AddDebtDialog> {
  final _formKey = GlobalKey<FormState>();
  final _descriptionController = TextEditingController();
  final _amountController = TextEditingController();
  DateTime _dueDate = DateTime.now().add(const Duration(days: 30));
  bool _isOwed = true;

  @override
  void dispose() {
    _descriptionController.dispose();
    _amountController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final localizedText = AppLocalizations.of(context);
    
    return AlertDialog(
      title: Text(localizedText?.translate('add_debt') ?? 'Add Debt'),
      content: Form(
        key: _formKey,
        child: SingleChildScrollView(
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              DropdownButtonFormField<bool>(
                value: _isOwed,
                items: [
                  DropdownMenuItem(
                    value: true,
                    child: Text(localizedText?.translate('you_owe') ?? 'You Owe'),
                  ),
                  DropdownMenuItem(
                    value: false,
                    child: Text(localizedText?.translate('owed_to_you') ?? 'Owed to You'),
                  ),
                ],
                onChanged: (value) => setState(() => _isOwed = value ?? true),
                decoration: InputDecoration(
                  labelText: localizedText?.translate('debt_type') ?? 'Debt Type',
                ),
              ),
              const SizedBox(height: 16),
              TextFormField(
                controller: _descriptionController,
                decoration: InputDecoration(
                  labelText: localizedText?.translate('description') ?? 'Description',
                ),
                validator: (value) => value?.isEmpty ?? true 
                    ? localizedText?.translate('description_required') ?? 'Description is required'
                    : null,
              ),
              const SizedBox(height: 16),
              TextFormField(
                controller: _amountController,
                keyboardType: TextInputType.number,
                decoration: InputDecoration(
                  labelText: localizedText?.translate('amount') ?? 'Amount',
                  prefixText: 'TND ',
                ),
                validator: (value) {
                  if (value?.isEmpty ?? true) {
                    return localizedText?.translate('amount_required') ?? 'Amount is required';
                  }
                  if (double.tryParse(value!) == null) {
                    return localizedText?.translate('valid_amount') ?? 'Enter a valid amount';
                  }
                  return null;
                },
              ),
              const SizedBox(height: 16),
              InkWell(
                onTap: () async {
                  final date = await showDatePicker(
                    context: context,
                    initialDate: _dueDate,
                    firstDate: DateTime.now(),
                    lastDate: DateTime.now().add(const Duration(days: 365 * 5)),
                  );
                  if (date != null) {
                    setState(() => _dueDate = date);
                  }
                },
                child: InputDecorator(
                  decoration: InputDecoration(
                    labelText: localizedText?.translate('due_date') ?? 'Due Date',
                  ),
                  child: Row(
                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                    children: [
                      Text(DateFormat.yMd().format(_dueDate)),
                      const Icon(Icons.calendar_today),
                    ],
                  ),
                ),
              ),
            ],
          ),
        ),
      ),
      actions: [
        TextButton(
          onPressed: () => Navigator.pop(context),
          child: Text(localizedText?.translate('cancel') ?? 'Cancel'),
        ),
        ElevatedButton(
          onPressed: _submitForm,
          child: Text(localizedText?.translate('add') ?? 'Add'),
        ),
      ],
    );
  }

  void _submitForm() async {
    if (_formKey.currentState?.validate() ?? false) {
      final authCtrl = Provider.of<AuthController>(context, listen: false);
      final debtCtrl = Provider.of<DebtController>(context, listen: false);
      
      final debt = Debt(
        id: '', // Will be generated by Firestore
        userId: authCtrl.currentUser?.uid ?? '',
        description: _descriptionController.text,
        amount: double.parse(_amountController.text),
        dueDate: _dueDate,
        isOwed: _isOwed,
        isPaid: false,
      );

      try {
        await debtCtrl.addDebt(debt);
        if (mounted) Navigator.pop(context);
      } catch (e) {
        if (mounted) {
          ScaffoldMessenger.of(context).showSnackBar(
            SnackBar(content: Text('Failed to add debt: $e')),
          );
        }
      }
    }
  }
}