import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'package:louiz/controllers/auth_controller.dart';
import 'package:louiz/utils/localization.dart';
import 'package:louiz/utils/constants.dart';

class SettingsScreen extends StatelessWidget {
  const SettingsScreen({super.key});

  @override
  Widget build(BuildContext context) {
    final authCtrl = Provider.of<AuthController>(context);
    final localizedText = AppLocalizations.of(context);
    
    return Scaffold(
      appBar: AppBar(
        title: Text(localizedText?.translate('settings') ?? 'Settings'),
      ),
      body: ListView(
        padding: const EdgeInsets.all(16),
        children: [
          ListTile(
            leading: const Icon(Icons.person),
            title: Text(localizedText?.translate('profile') ?? 'Profile'),
            subtitle: Text(authCtrl.currentUser?.email ?? ''),
            onTap: () {
              // Navigate to profile screen
            },
          ),
          const Divider(),
          ListTile(
            leading: const Icon(Icons.language),
            title: Text(localizedText?.translate('language') ?? 'Language'),
            subtitle: Text(_getCurrentLanguage(authCtrl.userLanguage ?? 'ar_TN')),
            onTap: () {
              _showLanguageDialog(context);
            },
          ),
          const Divider(),
          ListTile(
            leading: const Icon(Icons.notifications),
            title: Text(localizedText?.translate('notifications') ?? 'Notifications'),
            trailing: Switch(
              value: true, // This would come from user settings
              onChanged: (value) {
                // Update notification settings
              },
            ),
          ),
          const Divider(),
          ListTile(
            leading: const Icon(Icons.help),
            title: Text(localizedText?.translate('help') ?? 'Help'),
            onTap: () {
              // Navigate to help screen
            },
          ),
          const Divider(),
          ListTile(
            leading: const Icon(Icons.info),
            title: Text(localizedText?.translate('about') ?? 'About'),
            onTap: () {
              // Navigate to about screen
            },
          ),
          const Divider(),
          ListTile(
            leading: const Icon(Icons.logout, color: Colors.red),
            title: Text(
              localizedText?.translate('logout') ?? 'Logout',
              style: const TextStyle(color: Colors.red),
            ),
            onTap: () {
              authCtrl.logout();
            },
          ),
        ],
      ),
    );
  }

  String _getCurrentLanguage(String languageCode) {
    for (final entry in AppConstants.languageCodes.entries) {
      if (entry.value == languageCode) {
        return entry.key;
      }
    }
    return 'العربية'; // Default to Arabic
  }

  void _showLanguageDialog(BuildContext context) {
    final authCtrl = Provider.of<AuthController>(context, listen: false);
    final localizedText = AppLocalizations.of(context);
    
    showDialog(
      context: context,
      builder: (context) {
        return AlertDialog(
          title: Text(localizedText?.translate('select_language') ?? 'Select Language'),
          content: Column(
            mainAxisSize: MainAxisSize.min,
            children: AppConstants.languages.map((language) {
              return RadioListTile<String>(
                title: Text(language),
                value: AppConstants.languageCodes[language]!,
                groupValue: authCtrl.userLanguage ?? 'ar_TN',
                onChanged: (value) async {
                  if (value != null) {
                    await authCtrl.setUserLanguage(value);
                    if (context.mounted) {
                      Navigator.pop(context);
                    }
                  }
                },
              );
            }).toList(),
          ),
        );
      },
    );
  }
}