import 'package:flutter/material.dart';
import 'package:intl/intl.dart';
import 'package:provider/provider.dart';
import 'package:louiz/controllers/auth_controller.dart';
import 'package:louiz/controllers/budget_controller.dart';
import 'package:louiz/models/budget.dart';
import 'package:louiz/utils/constants.dart';
import 'package:louiz/utils/localization.dart';

class CreateBudgetScreen extends StatefulWidget {
  const CreateBudgetScreen({super.key});

  @override
  _CreateBudgetScreenState createState() => _CreateBudgetScreenState();
}

class _CreateBudgetScreenState extends State<CreateBudgetScreen> {
  final _formKey = GlobalKey<FormState>();
  final _totalAmountController = TextEditingController();
  
  DateTime _startDate = DateTime.now();
  DateTime _endDate = DateTime.now().add(const Duration(days: 30));
  
  final Map<String, TextEditingController> _categoryControllers = {};

  @override
  void initState() {
    super.initState();
    // Initialize controllers for each category
    for (final category in AppConstants.expenseCategories) {
      _categoryControllers[category] = TextEditingController();
    }
  }

  @override
  void dispose() {
    _totalAmountController.dispose();
    for (final controller in _categoryControllers.values) {
      controller.dispose();
    }
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final localizedText = AppLocalizations.of(context);
    
    return Scaffold(
      appBar: AppBar(
        title: Text(localizedText?.translate('create_budget') ?? 'Create Budget'),
      ),
      body: SingleChildScrollView(
        padding: const EdgeInsets.all(16),
        child: Form(
          key: _formKey,
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Text(
                localizedText?.translate('budget_period') ?? 'Budget Period',
                style: Theme.of(context).textTheme.titleMedium,
              ),
              const SizedBox(height: 8),
              Row(
                children: [
                  Expanded(
                    child: InkWell(
                      onTap: () async {
                        final date = await showDatePicker(
                          context: context,
                          initialDate: _startDate,
                          firstDate: DateTime.now(),
                          lastDate: DateTime.now().add(const Duration(days: 365)),
                        );
                        if (date != null) {
                          setState(() => _startDate = date);
                        }
                      },
                      child: InputDecorator(
                        decoration: InputDecoration(
                          labelText: localizedText?.translate('start_date') ?? 'Start Date',
                          border: OutlineInputBorder(),
                        ),
                        child: Row(
                          mainAxisAlignment: MainAxisAlignment.spaceBetween,
                          children: [
                            Text(DateFormat.yMd().format(_startDate)),
                            const Icon(Icons.calendar_today),
                          ],
                        ),
                      ),
                    ),
                  ),
                  const SizedBox(width: 16),
                  Expanded(
                    child: InkWell(
                      onTap: () async {
                        final date = await showDatePicker(
                          context: context,
                          initialDate: _endDate,
                          firstDate: _startDate,
                          lastDate: DateTime.now().add(const Duration(days: 365)),
                        );
                        if (date != null) {
                          setState(() => _endDate = date);
                        }
                      },
                      child: InputDecorator(
                        decoration: InputDecoration(
                          labelText: localizedText?.translate('end_date') ?? 'End Date',
                          border: OutlineInputBorder(),
                        ),
                        child: Row(
                          mainAxisAlignment: MainAxisAlignment.spaceBetween,
                          children: [
                            Text(DateFormat.yMd().format(_endDate)),
                            const Icon(Icons.calendar_today),
                          ],
                        ),
                      ),
                    ),
                  ),
                ],
              ),
              const SizedBox(height: 24),
              TextFormField(
                controller: _totalAmountController,
                keyboardType: TextInputType.number,
                decoration: InputDecoration(
                  labelText: localizedText?.translate('total_amount') ?? 'Total Amount',
                  prefixText: 'TND ',
                  border: OutlineInputBorder(),
                ),
                validator: (value) {
                  if (value == null || value.isEmpty) {
                    return localizedText?.translate('amount_required') ?? 'Amount is required';
                  }
                  if (double.tryParse(value) == null) {
                    return localizedText?.translate('valid_amount') ?? 'Enter a valid amount';
                  }
                  return null;
                },
              ),
              const SizedBox(height: 24),
              Text(
                localizedText?.translate('category_limits') ?? 'Category Limits',
                style: Theme.of(context).textTheme.titleMedium,
              ),
              const SizedBox(height: 8),
              ...AppConstants.expenseCategories.map((category) {
                return Padding(
                  padding: const EdgeInsets.only(bottom: 16),
                  child: TextFormField(
                    controller: _categoryControllers[category],
                    keyboardType: TextInputType.number,
                    decoration: InputDecoration(
                      labelText: category,
                      prefixText: 'TND ',
                      border: OutlineInputBorder(),
                    ),
                    validator: (value) {
                      if (value != null && value.isNotEmpty && double.tryParse(value) == null) {
                        return localizedText?.translate('valid_amount') ?? 'Enter a valid amount';
                      }
                      return null;
                    },
                  ),
                );
              }),
              const SizedBox(height: 24),
              Center(
                child: ElevatedButton(
                  onPressed: _createBudget,
                  child: Text(localizedText?.translate('create_budget') ?? 'Create Budget'),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }

  Future<void> _createBudget() async {
    if (!mounted) return;
    if (_formKey.currentState?.validate() ?? false) {
      final totalAmount = double.parse(_totalAmountController.text);
      
      final categoryLimits = <String, double>{};
      double enteredTotal = 0;
      
      for (final entry in _categoryControllers.entries) {
        if (entry.value.text.isNotEmpty) {
          final amount = double.parse(entry.value.text);
          categoryLimits[entry.key] = amount;
          enteredTotal += amount;
        }
      }
      
      if (enteredTotal > totalAmount) {
        if (!mounted) return;
        final localizedText = AppLocalizations.of(context);
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(
            content: Text(localizedText?.translate('category_exceeds_total') ?? 
                'Category limits exceed total budget amount'),
          ),
        );
        return;
      }
      
      final budget = Budget(
        id: DateTime.now().millisecondsSinceEpoch.toString(),
        userId: Provider.of<AuthController>(context, listen: false).currentUser?.uid ?? '',
        totalAmount: totalAmount,
        categoryLimits: categoryLimits,
        startDate: _startDate,
        endDate: _endDate,
      );
      
      try {
        await Provider.of<BudgetController>(context, listen: false)
            .createBudget(budget);
        if (!mounted) return;
        Navigator.pop(context);
      } catch (e) {
        if (!mounted) return;
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(content: Text('Failed to create budget: $e')),
        );
      }
    }
  }
}