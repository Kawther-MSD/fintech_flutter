import 'package:flutter/material.dart';
import 'package:flutter/cupertino.dart';  // Added for Cupertino localizations
import 'package:flutter_localizations/flutter_localizations.dart';  // Added for Material localizations


class AppLocalizations {
  final Locale locale;

  AppLocalizations(this.locale);

  static AppLocalizations? of(BuildContext context) {
    return Localizations.of<AppLocalizations>(context, AppLocalizations);
  }

  static const LocalizationsDelegate<AppLocalizations> delegate = _AppLocalizationsDelegate();

  static final Map<String, Map<String, String>> _localizedValues = {
    'en': {
      'app_title': 'Louiz',
      'login': 'Login',
      'welcome': 'Welcome',
      'budget': 'Budget',
      'savings': 'Savings',
      'debts': 'Debts',
      'transactions': 'Transactions',
      'settings': 'Settings',
      'logout': 'Logout',
      'voice_expense_added': 'Expense added',
      'voice_income_added': 'Income added',
      'voice_debt_added': 'Debt recorded',
      'voice_savings_added': 'Savings added',
      'voice_amount_missing': 'Amount not specified',
      'voice_debt_missing_info': 'Missing debt information',
      'voice_command_not_understood': 'Command not understood',
      'notification_budget_warning_title': 'Budget Warning',
      'notification_budget_warning_body': 'You\'re about to exceed your monthly budget!',
      'notification_budget_alert_title': 'Budget Alert',
      'notification_budget_alert_body': 'Your spending is high this month, let\'s talk about it?',
      'notification_category_warning_title': 'Category Warning',
      'notification_category_warning_body': 'You\'re about to exceed your budget for',
      'notification_savings_half_title': 'Savings Progress',
      'notification_savings_half_body': 'Great job! You reached',
      'notification_savings_of_goal': 'of your',
      'notification_savings_almost_title': 'Almost There!',
      'notification_savings_almost_body': 'You saved',
      'notification_savings_almost_continue': 'keep going!',
      'notification_debt_due_title': 'Debt Due',
      'notification_debt_due_body': 'Your',
      'notification_debt_due_tomorrow': 'is due tomorrow!',
      'notification_debt_overdue_title': 'Overdue Debt',
      'notification_debt_overdue_body': 'You haven\'t paid',
    },
    'fr': {
      'app_title': 'Louiz',
      'login': 'Connexion',
      'welcome': 'Bienvenue',
      'budget': 'Budget',
      'savings': 'Économies',
      'debts': 'Dettes',
      'transactions': 'Transactions',
      'settings': 'Paramètres',
      'logout': 'Déconnexion',
      'voice_expense_added': 'Dépense ajoutée',
      'voice_income_added': 'Revenu ajouté',
      'voice_debt_added': 'Dette enregistrée',
      'voice_savings_added': 'Économies ajoutées',
      'voice_amount_missing': 'Montant non spécifié',
      'voice_debt_missing_info': 'Informations sur la dette manquantes',
      'voice_command_not_understood': 'Commande non comprise',
      'notification_budget_warning_title': 'Avertissement Budget',
      'notification_budget_warning_body': 'Vous êtes sur le point de dépasser votre budget mensuel!',
      'notification_budget_alert_title': 'Alerte Budget',
      'notification_budget_alert_body': 'Vos dépenses sont élevées ce mois-ci, on en parle?',
      'notification_category_warning_title': 'Avertissement Catégorie',
      'notification_category_warning_body': 'Vous êtes sur le point de dépasser votre budget pour',
      'notification_savings_half_title': 'Progrès Économies',
      'notification_savings_half_body': 'Bon travail! Vous avez atteint',
      'notification_savings_of_goal': 'de votre object',
      'notification_savings_almost_title': 'Presque Là!',
      'notification_savings_almost_body': 'Vous avez économisé',
      'notification_savings_almost_continue': 'continuez!',
      'notification_debt_due_title': 'Dette Due',
      'notification_debt_due_body': 'Votre',
      'notification_debt_due_tomorrow': 'est due demain!',
      'notification_debt_overdue_title': 'Dette En Retard',
      'notification_debt_overdue_body': 'Vous n\'avez pas payé',
    },
    'ar': {
      'app_title': 'لوّيز',
      'login': 'تسجيل الدخول',
      'welcome': 'مرحبا بك',
      'budget': 'الميزانية',
      'savings': 'المدخرات',
      'debts': 'الدين والمستحقات',
      'transactions': 'المعاملات',
      'settings': 'الإعدادات',
      'logout': 'تسجيل الخروج',
      'voice_expense_added': 'تمت إضافة المصروف',
      'voice_income_added': 'تمت إضافة الدخل',
      'voice_debt_added': 'تم تسجيل الدين',
      'voice_savings_added': 'تمت إضافة المدخرات',
      'voice_amount_missing': 'لم يتم تحديد المبلغ',
      'voice_debt_missing_info': 'معلومات الدين ناقصة',
      'voice_command_not_understood': 'لم أفهم الأمر',
      'notification_budget_warning_title': 'تحذير الميزانية',
      'notification_budget_warning_body': 'راك قريب تكمّل الميزانية الشهرية!',
      'notification_budget_alert_title': 'تنبيه الميزانية',
      'notification_budget_alert_body': 'راهو صرفك طلع برشة الشهر هذا، نحكيوا عليه؟',
      'notification_category_warning_title': 'تحذير الفئة',
      'notification_category_warning_body': 'راك قريب تكمّل ميزانية',
      'notification_savings_half_title': 'تقدم في الادخار',
      'notification_savings_half_body': 'يعطيك الصحة! وصلنا',
      'notification_savings_of_goal': 'من هدف',
      'notification_savings_almost_title': 'قريب من الهدف!',
      'notification_savings_almost_body': 'راك موفّر',
      'notification_savings_almost_continue': 'قريب نوصلوا!',
      'notification_debt_due_title': 'استحقاق الدين',
      'notification_debt_due_body': 'هاو',
      'notification_debt_due_tomorrow': 'تخلص غداً!',
      'notification_debt_overdue_title': 'تأخر في السداد',
      'notification_debt_overdue_body': 'راك مازلت مخلّصتش',
    },
  };

  String translate(String key) {
    return _localizedValues[locale.languageCode]?[key] ?? key;
  }

  static List<Locale> supportedLocales() {
    return const [
      Locale('en', 'US'),
      Locale('fr', 'FR'),
      Locale('ar', 'TN'),
    ];
  }

  static Locale localeResolutionCallback(Locale? locale, Iterable<Locale> supportedLocales) {
    for (final supportedLocale in supportedLocales) {
      if (supportedLocale.languageCode == locale?.languageCode) {
        return supportedLocale;
      }
    }
    return supportedLocales.first;
  }

  static const localizationsDelegates = [
    delegate,
    GlobalMaterialLocalizations.delegate,
    GlobalWidgetsLocalizations.delegate,
    GlobalCupertinoLocalizations.delegate,
  ];
}

class _AppLocalizationsDelegate extends LocalizationsDelegate<AppLocalizations> {
  const _AppLocalizationsDelegate();

  @override
  bool isSupported(Locale locale) {
    return ['en', 'fr', 'ar'].contains(locale.languageCode);
  }

  @override
  Future<AppLocalizations> load(Locale locale) async {
    return AppLocalizations(locale);
  }

  @override
  bool shouldReload(_AppLocalizationsDelegate old) => false;
}