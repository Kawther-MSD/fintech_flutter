class AppConstants {
  static const List<String> expenseCategories = [
    'Food',
    'Transport',
    'Housing',
    'Utilities',
    'Healthcare',
    'Entertainment',
    'Shopping',
    'Education',
    'Personal Care',
    'Other'
  ];

  static const List<String> incomeCategories = [
    'Salary',
    'Bonus',
    'Investment',
    'Gift',
    'Freelance',
    'Other'
  ];

  static const Map<String, String> categoryIcons = {
    'Food': 'assets/icons/food.svg',
    'Transport': 'assets/icons/transport.svg',
    'Housing': 'assets/icons/housing.svg',
    'Utilities': 'assets/icons/utilities.svg',
    'Healthcare': 'assets/icons/healthcare.svg',
    'Entertainment': 'assets/icons/entertainment.svg',
    'Shopping': 'assets/icons/shopping.svg',
    'Education': 'assets/icons/education.svg',
    'Personal Care': 'assets/icons/personal_care.svg',
    'Salary': 'assets/icons/salary.svg',
    'Bonus': 'assets/icons/bonus.svg',
    'Investment': 'assets/icons/investment.svg',
    'Gift': 'assets/icons/gift.svg',
    'Freelance': 'assets/icons/freelance.svg',
    'Other': 'assets/icons/other.svg',
  };

  static const List<String> languages = [
    'العربية',
    'Français',
    'English'
  ];

  static const Map<String, String> languageCodes = {
    'العربية': 'ar_TN',
    'Français': 'fr_FR',
    'English': 'en_US',
  };
}