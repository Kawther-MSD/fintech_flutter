import 'package:flutter/material.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:louiz/models/budget.dart';
import 'package:louiz/models/transaction.dart' as transaction_model;

class BudgetController with ChangeNotifier {
  Budget? _currentBudget;
  double _totalSpent = 0;
  Map<String, double> _categorySpending = {};

  Budget? get currentBudget => _currentBudget;
  double get totalSpent => _totalSpent;
  Map<String, double> get categorySpending => _categorySpending;

  final FirebaseFirestore _firestore = FirebaseFirestore.instance;

  Future<void> createBudget(Budget budget) async {
    try {
      await _firestore.collection('budgets').doc(budget.id).set(budget.toMap());
      _currentBudget = budget;
      _totalSpent = 0;
      _categorySpending = {};
      notifyListeners();
    } catch (e) {
      debugPrint('Error creating budget: $e');
      rethrow;
    }
  }

  Future<void> fetchCurrentBudget(String userId) async {
    try {
      final snapshot = await _firestore
          .collection('budgets')
          .where('userId', isEqualTo: userId)
          .orderBy('startDate', descending: true)
          .limit(1)
          .get();

      if (snapshot.docs.isNotEmpty) {
        _currentBudget = Budget.fromFirestore(snapshot.docs.first);
        await _calculateSpending();
      } else {
        _currentBudget = null;
        _totalSpent = 0;
        _categorySpending = {};
      }
      notifyListeners();
    } catch (e) {
      debugPrint('Error fetching current budget: $e');
    }
  }

  Future<void> _calculateSpending() async {
    if (_currentBudget == null) return;

    try {
      final transactions = await _firestore
          .collection('transactions')
          .where('userId', isEqualTo: _currentBudget!.userId)
          .where('date', isGreaterThanOrEqualTo: _currentBudget!.startDate)
          .where('date', isLessThanOrEqualTo: _currentBudget!.endDate)
          .get();

      _totalSpent = transactions.docs
          .where((doc) => transaction_model.Transaction.fromFirestore(doc).type == 
              transaction_model.TransactionType.expense)
          .fold(0, (sum, doc) => sum + (doc.data()['amount'] as num).toDouble());

      _categorySpending = {};
      for (final doc in transactions.docs) {
        final transaction = transaction_model.Transaction.fromFirestore(doc);
        if (transaction.type == transaction_model.TransactionType.expense) {
          _categorySpending.update(
            transaction.category,
            (value) => value + transaction.amount,
            ifAbsent: () => transaction.amount,
          );
        }
      }
    } catch (e) {
      debugPrint('Error calculating spending: $e');
    }
  }
}