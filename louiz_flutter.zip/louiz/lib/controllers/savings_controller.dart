import 'package:flutter/material.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:louiz/models/savings_goal.dart';

class SavingsController with ChangeNotifier {
  List<SavingsGoal> _savingsGoals = [];
  final FirebaseFirestore _firestore = FirebaseFirestore.instance;

  List<SavingsGoal> get savingsGoals => _savingsGoals;

  Future<void> createSavingsGoal(SavingsGoal goal) async {
    try {
      await _firestore.collection('savingsGoals').doc(goal.id).set(goal.toMap());
      _savingsGoals.add(goal);
      notifyListeners();
    } catch (e) {
      debugPrint('Error creating savings goal: $e');
      rethrow;
    }
  }

  Future<void> fetchSavingsGoals(String userId) async {
    try {
      final snapshot = await _firestore
          .collection('savingsGoals')
          .where('userId', isEqualTo: userId)
          .orderBy('targetDate')
          .get();

      _savingsGoals = snapshot.docs
          .map((doc) => SavingsGoal.fromFirestore(doc))
          .toList();
      notifyListeners();
    } catch (e) {
      debugPrint('Error fetching savings goals: $e');
    }
  }

  Future<void> updateSavingsGoal(SavingsGoal updatedGoal) async {
    try {
      await _firestore
          .collection('savingsGoals')
          .doc(updatedGoal.id)
          .update(updatedGoal.toMap());

      final index = _savingsGoals.indexWhere((goal) => goal.id == updatedGoal.id);
      if (index != -1) {
        _savingsGoals[index] = updatedGoal;
        notifyListeners();
      }
    } catch (e) {
      debugPrint('Error updating savings goal: $e');
      rethrow;
    }
  }

  Future<void> deleteSavingsGoal(String goalId) async {
    try {
      await _firestore.collection('savingsGoals').doc(goalId).delete();
      _savingsGoals.removeWhere((goal) => goal.id == goalId);
      notifyListeners();
    } catch (e) {
      debugPrint('Error deleting savings goal: $e');
      rethrow;
    }
  }

  Future<void> addToSavingsGoal(String goalId, double amount) async {
    try {
      final goal = _savingsGoals.firstWhere((g) => g.id == goalId);
      final updatedGoal = SavingsGoal(
        id: goal.id,
        userId: goal.userId,
        name: goal.name,
        currentAmount: goal.currentAmount + amount,
        targetAmount: goal.targetAmount,
        targetDate: goal.targetDate,
      );

      await updateSavingsGoal(updatedGoal);
    } catch (e) {
      debugPrint('Error adding to savings goal: $e');
      rethrow;
    }
  }

  Future<void> withdrawFromSavingsGoal(String goalId, double amount) async {
    try {
      final goal = _savingsGoals.firstWhere((g) => g.id == goalId);
      if (goal.currentAmount < amount) {
        throw Exception('Insufficient funds in savings goal');
      }

      final updatedGoal = SavingsGoal(
        id: goal.id,
        userId: goal.userId,
        name: goal.name,
        currentAmount: goal.currentAmount - amount,
        targetAmount: goal.targetAmount,
        targetDate: goal.targetDate,
      );

      await updateSavingsGoal(updatedGoal);
    } catch (e) {
      debugPrint('Error withdrawing from savings goal: $e');
      rethrow;
    }
  }

  double getTotalSaved() {
    return _savingsGoals.fold(0, (sum, goal) => sum + goal.currentAmount);
  }

  double getTotalTarget() {
    return _savingsGoals.fold(0, (sum, goal) => sum + goal.targetAmount);
  }

  double getOverallProgress() {
    final totalSaved = getTotalSaved();
    final totalTarget = getTotalTarget();
    return totalTarget > 0 ? (totalSaved / totalTarget) : 0;
  }
}