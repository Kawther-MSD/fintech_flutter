import 'package:flutter/material.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:cloud_firestore/cloud_firestore.dart';

class AuthController with ChangeNotifier {
  User? _currentUser;
  String? _userLanguage;

  User? get currentUser => _currentUser;
  String? get userLanguage => _userLanguage;
  bool get isAuthenticated => _currentUser != null; // Add this line

  final FirebaseAuth _auth = FirebaseAuth.instance;
  final FirebaseFirestore _firestore = FirebaseFirestore.instance;

  AuthController() {
    _auth.authStateChanges().listen((User? user) {
      _currentUser = user;
      if (user != null) {
        _loadUserPreferences();
      }
      notifyListeners();
    });
  }

  Future<void> _loadUserPreferences() async {
    if (_currentUser == null) return;
    
    final doc = await _firestore.collection('users').doc(_currentUser!.uid).get();
    if (doc.exists) {
      _userLanguage = doc.data()?['language'] ?? 'ar_TN';
      notifyListeners();
    }
  }

  Future<void> setUserLanguage(String languageCode) async {
    if (_currentUser == null) return;
    
    _userLanguage = languageCode;
    await _firestore.collection('users').doc(_currentUser!.uid).update({
      'language': languageCode,
    });
    notifyListeners();
  }

  Future<void> signup(String email, String password, String name) async {
    try {
      UserCredential result = await _auth.createUserWithEmailAndPassword(
        email: email,
        password: password,
      );
      
      await _firestore.collection('users').doc(result.user?.uid).set({
        'name': name,
        'email': email,
        'createdAt': FieldValue.serverTimestamp(),
        'preferredLanguage': 'ar_TN',
        'currency': 'TND',
      });
      
      _currentUser = result.user;
      _userLanguage = 'ar_TN';
      notifyListeners();
    } catch (e) {
      rethrow;
    }
  }

  Future<void> logout() async {
    await _auth.signOut();
    _currentUser = null;
    _userLanguage = null;
  }
}