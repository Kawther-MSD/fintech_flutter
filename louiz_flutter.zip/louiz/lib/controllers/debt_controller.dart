import 'package:flutter/material.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:louiz/models/debt.dart';

class DebtController with ChangeNotifier {
  final FirebaseFirestore _firestore = FirebaseFirestore.instance;
  List<Debt> _owedDebts = [];
  List<Debt> _dueDebts = [];
  bool _isLoading = false;

  List<Debt> get owedDebts => _owedDebts;
  List<Debt> get dueDebts => _dueDebts;
  bool get isLoading => _isLoading;

  Future<void> fetchDebts(String userId) async {
    _isLoading = true;
    notifyListeners();

    try {
      // Get debts you owe
      final owedSnapshot = await _firestore
          .collection('debts')
          .where('userId', isEqualTo: userId)
          .where('isOwed', isEqualTo: true)
          .get();

      // Get debts owed to you
      final dueSnapshot = await _firestore
          .collection('debts')
          .where('userId', isEqualTo: userId)
          .where('isOwed', isEqualTo: false)
          .get();

      _owedDebts = owedSnapshot.docs
          .map((doc) => Debt.fromFirestore(doc))
          .toList();

      _dueDebts = dueSnapshot.docs
          .map((doc) => Debt.fromFirestore(doc))
          .toList();
    } catch (e) {
      debugPrint('Error fetching debts: $e');
    } finally {
      _isLoading = false;
      notifyListeners();
    }
  }

  Future<void> addDebt(Debt debt) async {
    try {
      await _firestore.collection('debts').add(debt.toMap());
      await fetchDebts(debt.userId); // Refresh the list
    } catch (e) {
      debugPrint('Error adding debt: $e');
      rethrow;
    }
  }

  Future<void> updateDebtStatus(String debtId, bool isPaid) async {
    try {
      await _firestore.collection('debts').doc(debtId).update({
        'isPaid': isPaid,
      });
      // Refresh debts for both tabs since status might affect categorization
      final userId = _owedDebts.firstWhere(
        (d) => d.id == debtId,
        orElse: () => _dueDebts.firstWhere((d) => d.id == debtId),
      ).userId;
      await fetchDebts(userId);
    } catch (e) {
      debugPrint('Error updating debt status: $e');
      rethrow;
    }
  }

  Future<void> deleteDebt(String debtId) async {
    try {
      await _firestore.collection('debts').doc(debtId).delete();
      // Refresh debts
      final userId = _owedDebts.firstWhere(
        (d) => d.id == debtId,
        orElse: () => _dueDebts.firstWhere((d) => d.id == debtId),
      ).userId;
      await fetchDebts(userId);
    } catch (e) {
      debugPrint('Error deleting debt: $e');
      rethrow;
    }
  }
}