import 'package:flutter/material.dart';
import 'package:louiz/models/transaction.dart' as model;
import 'package:louiz/services/database_service.dart';

class TransactionController with ChangeNotifier {
  final DatabaseService _databaseService = DatabaseService();
  List<model.Transaction> _transactions = [];
  bool _isLoading = false;

  List<model.Transaction> get transactions => _transactions;
  List<model.Transaction> get recentTransactions => _transactions.take(5).toList();
  bool get isLoading => _isLoading;

  double get totalIncome => _transactions
      .where((t) => t.type == model.TransactionType.income)
      .fold(0, (total, t) => total + t.amount);

  double get totalExpenses => _transactions
      .where((t) => t.type == model.TransactionType.expense)
      .fold(0, (total, t) => total + t.amount);

  double get totalSavings => _transactions
      .where((t) => t.type == model.TransactionType.savings)
      .fold(0, (total, t) => total + t.amount);

  Future<void> fetchTransactions(String userId) async {
    _isLoading = true;
    notifyListeners();
    
    try {
      final transactions = await _databaseService.getTransactions(userId);
      _transactions = transactions;
    } catch (e) {
      debugPrint('Error fetching transactions: $e');
    } finally {
      _isLoading = false;
      notifyListeners();
    }
  }

  Future<void> addTransaction(model.Transaction transaction) async {
    try {
      await _databaseService.addTransaction(transaction);
      _transactions.insert(0, transaction);
      notifyListeners();
    } catch (e) {
      debugPrint('Error adding transaction: $e');
      rethrow;
    }
  }

  Future<void> deleteTransaction(String transactionId) async {
    try {
      await _databaseService.deleteTransaction(transactionId);
      _transactions.removeWhere((t) => t.id == transactionId);
      notifyListeners();
    } catch (e) {
      debugPrint('Error deleting transaction: $e');
      rethrow;
    }
  }
}