import 'package:flutter/material.dart';
import 'package:speech_to_text/speech_to_text.dart' as stt;
import 'package:flutter_tts/flutter_tts.dart';
import 'package:louiz/utils/localization.dart';

class VoiceController with ChangeNotifier {
  final stt.SpeechToText _speech = stt.SpeechToText();
  final FlutterTts _tts = FlutterTts();
  bool _isListening = false;
  String _recognizedText = '';
  String? _lastError;

  bool get isListening => _isListening;
  String get recognizedText => _recognizedText;
  String? get lastError => _lastError;

  Future<void> initSpeech() async {
    try {
      await _speech.initialize();
      await _tts.setLanguage('ar-TN');
    } catch (e) {
      _lastError = 'Failed to initialize speech: $e';
      notifyListeners();
    }
  }

  Future<void> startListening() async {
    if (!_isListening) {
      _isListening = true;
      _recognizedText = '';
      notifyListeners();
      
      await _speech.listen(
        onResult: (result) {
          _recognizedText = result.recognizedWords;
          notifyListeners();
        },
        localeId: 'ar_TN',
      );
    }
  }

  Future<void> stopListening() async {
    if (_isListening) {
      _isListening = false;
      await _speech.stop();
      notifyListeners();
    }
  }

  Future<void> speak(String text) async {
    await _tts.speak(text);
  }

  Future<void> processVoiceCommand(String command, BuildContext context) async {
    final locale = Localizations.localeOf(context);
    final localizedText = AppLocalizations.of(context);
    
    // Simple voice command processing for Tunisian Arabic
    if (command.contains('صرفت') || command.contains('دفعت')) {
      // Expense transaction
      final amount = _extractAmount(command);
      final category = _extractCategory(command);
      
      if (amount != null) {
        await speak(localizedText?.translate('voice_expense_added') ?? 'تمت إضافة المصروف');
        // Here you would call the transaction controller to add the expense
      } else {
        await speak(localizedText?.translate('voice_amount_missing') ?? 'لم يتم تحديد المبلغ');
      }
    } else if (command.contains('جاني') || command.contains('حصلت')) {
      // Income transaction
      final amount = _extractAmount(command);
      
      if (amount != null) {
        await speak(localizedText?.translate('voice_income_added') ?? 'تمت إضافة الدخل');
        // Call transaction controller to add income
      } else {
        await speak(localizedText?.translate('voice_amount_missing') ?? 'لم يتم تحديد المبلغ');
      }
    } else if (command.contains('سلفت') || command.contains('قرضت')) {
      // Debt given
      final amount = _extractAmount(command);
      final person = _extractPerson(command);
      
      if (amount != null && person != null) {
        await speak('${localizedText?.translate('voice_debt_added') ?? 'تم تسجيل الدين ل'} $person');
        // Call debt controller to add debt
      } else {
        await speak(localizedText?.translate('voice_debt_missing_info') ?? 'معلومات الدين ناقصة');
      }
    } else if (command.contains('ادخرت') || command.contains('حفظت')) {
      // Savings
      final amount = _extractAmount(command);
      
      if (amount != null) {
        await speak(localizedText?.translate('voice_savings_added') ?? 'تمت إضافة المدخرات');
        // Call savings controller to add to savings
      } else {
        await speak(localizedText?.translate('voice_amount_missing') ?? 'لم يتم تحديد المبلغ');
      }
    } else {
      await speak(localizedText?.translate('voice_command_not_understood') ?? 'لم أفهم الأمر');
    }
  }

  double? _extractAmount(String text) {
    final regex = RegExp(r'(\d+(\.\d+)?)');
    final match = regex.firstMatch(text);
    if (match != null) {
      return double.parse(match.group(1)!);
    }
    return null;
  }

  String? _extractCategory(String text) {
    // Map Tunisian dialect words to categories
    if (text.contains('مطعم') || text.contains('مأكولات') || text.contains('اكل')) {
      return 'Food';
    } else if (text.contains('قهوة') || text.contains('كافيه')) {
      return 'Coffee';
    } else if (text.contains('سيارة') || text.contains('بنزين') || text.contains('تكسي')) {
      return 'Transport';
    } else if (text.contains('ملابس') || text.contains('لبس')) {
      return 'Clothing';
    }
    return 'Other';
  }

  String? _extractPerson(String text) {
    // Very simple extraction - would need NLP for better results
    final parts = text.split(' ');
    if (parts.length > 2) {
      return parts[2]; // Assuming format "سلفت [اسم] [المبلغ]"
    }
    return null;
  }
}