import 'package:flutter/material.dart';
import 'package:louiz/services/notification_service.dart';
import 'package:louiz/models/budget.dart';
import 'package:louiz/models/savings_goal.dart';
import 'package:louiz/models/debt.dart';
import 'package:louiz/utils/localization.dart';
import 'package:louiz/models/notification.dart' as model;

class NotificationController with ChangeNotifier {
  final NotificationService _notificationService = NotificationService();
  List<model.AppNotification> _notifications = [];
  bool _isLoading = false;

  List<model.AppNotification> get notifications => _notifications;
  bool get isLoading => _isLoading;

  Future<void> fetchNotifications(String userId) async {
    _isLoading = true;
    notifyListeners();
    
    try {
      _notifications = await _notificationService.getNotifications(userId);
    } catch (e) {
      debugPrint('Error fetching notifications: $e');
    } finally {
      _isLoading = false;
      notifyListeners();
    }
  }

  Future<void> checkForBudgetNotifications(
    BuildContext context, 
    Budget budget, 
    double spentAmount,
    Map<String, double> categorySpending,
  ) async {
    final localizedText = AppLocalizations.of(context);
    final totalPercentage = spentAmount / budget.totalAmount;
    
    if (totalPercentage > 0.8) {
      await _notificationService.sendNotification(
        title: localizedText?.translate('notification_budget_warning_title') ?? 'Budget Warning',
        body: localizedText?.translate('notification_budget_warning_body') ?? 'You\'re about to exceed your monthly budget!',
        userId: budget.userId,
      );
    } else if (totalPercentage > 0.5) {
      await _notificationService.sendNotification(
        title: localizedText?.translate('notification_budget_alert_title') ?? 'Budget Alert',
        body: localizedText?.translate('notification_budget_alert_body') ?? 'Your spending is high this month',
        userId: budget.userId,
      );
    }
    
    for (final entry in categorySpending.entries) {
      final categoryLimit = budget.categoryLimits[entry.key] ?? 0;
      if (categoryLimit > 0) {
        final categoryPercentage = entry.value / categoryLimit;
        if (categoryPercentage > 0.9) {
          await _notificationService.sendNotification(
            title: localizedText?.translate('notification_category_warning_title') ?? 'Category Warning',
            body: '${localizedText?.translate('notification_category_warning_body') ?? 'You\'re about to exceed budget for'} ${entry.key}!',
            userId: budget.userId,
          );
        }
      }
    }
  }

  Future<void> checkForSavingsNotifications(
  BuildContext context,
  SavingsGoal goal,  // Changed to direct class reference
) async {
  final localizedText = AppLocalizations.of(context);
  final percentage = goal.currentAmount / goal.targetAmount;
  
  if (percentage > 0.5 && percentage < 0.75) {
    await _notificationService.sendNotification(
      title: localizedText?.translate('notification_savings_half_title') ?? 'Savings Progress',
      body: '${localizedText?.translate('notification_savings_half_body') ?? 'Great job! You reached'} ${(percentage * 100).toStringAsFixed(0)}% ${localizedText?.translate('notification_savings_of_goal') ?? 'of your'} ${goal.name}',
      userId: goal.userId,
    );
  } else if (percentage >= 0.75) {
    await _notificationService.sendNotification(
      title: localizedText?.translate('notification_savings_almost_title') ?? 'Almost There!',
      body: '${localizedText?.translate('notification_savings_almost_body') ?? 'You saved'} ${(percentage * 100).toStringAsFixed(0)}% ${localizedText?.translate('notification_savings_of_goal') ?? 'of your'} ${goal.name}',
      userId: goal.userId,
    );
  }
}

  Future<void> checkForDebtNotifications(
    BuildContext context,
    Debt debt,
  ) async {
    final localizedText = AppLocalizations.of(context);
    final now = DateTime.now();
    final dueIn = debt.dueDate.difference(now).inDays;
    
    if (dueIn == 1 && !debt.isPaid) {
      await _notificationService.sendNotification(
        title: localizedText?.translate('notification_debt_due_title') ?? 'Debt Due',
        body: '${localizedText?.translate('notification_debt_due_body') ?? 'Your'} ${debt.description} ${localizedText?.translate('notification_debt_due_tomorrow') ?? 'is due tomorrow!'}',
        userId: debt.userId,
      );
    } else if (dueIn < 0 && !debt.isPaid) {
      await _notificationService.sendNotification(
        title: localizedText?.translate('notification_debt_overdue_title') ?? 'Overdue Debt',
        body: '${localizedText?.translate('notification_debt_overdue_body') ?? 'You haven\'t paid'} ${debt.description}!',
        userId: debt.userId,
      );
    }
  }

  Future<void> sendDailyReminder(String userId) async {
    await _notificationService.sendNotification(
      title: 'Good morning!',
      body: 'Would you like to log today\'s expenses?',
      userId: userId,
    );
  }

  Future<void> sendMonthlySummary(String userId, double savingsRate) async {
    if (savingsRate > 0.2) {
      await _notificationService.sendNotification(
        title: 'Congratulations!',
        body: 'You saved ${(savingsRate * 100).toStringAsFixed(0)}% of your income this month!',
        userId: userId,
      );
    } else if (savingsRate < 0) {
      await _notificationService.sendNotification(
        title: 'Watch your spending',
        body: 'You spent more than you earned this month. Need help planning for next month?',
        userId: userId,
      );
    }
  }
}