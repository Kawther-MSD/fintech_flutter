import 'package:cloud_firestore/cloud_firestore.dart';

class Budget {
  final String id;
  final String userId;
  final double totalAmount;
  final Map<String, double> categoryLimits;
  final DateTime startDate;
  final DateTime endDate;

  Budget({
    required this.id,
    required this.userId,
    required this.totalAmount,
    required this.categoryLimits,
    required this.startDate,
    required this.endDate,
  });

  factory Budget.fromFirestore(DocumentSnapshot<Map<String, dynamic>> doc) {
    final data = doc.data()!;
    return Budget(
      id: doc.id,
      userId: data['userId'] as String,
      totalAmount: (data['totalAmount'] as num).toDouble(),
      categoryLimits: (data['categoryLimits'] as Map).map((key, value) => 
        MapEntry(key as String, (value as num).toDouble())),
      startDate: (data['startDate'] as Timestamp).toDate(),
      endDate: (data['endDate'] as Timestamp).toDate(),
    );
  }

  Map<String, dynamic> toMap() {
    return {
      'userId': userId,
      'totalAmount': totalAmount,
      'categoryLimits': categoryLimits,
      'startDate': Timestamp.fromDate(startDate),
      'endDate': Timestamp.fromDate(endDate),
    };
  }
}