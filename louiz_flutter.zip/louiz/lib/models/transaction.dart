import 'package:cloud_firestore/cloud_firestore.dart';

enum TransactionType { expense, income, savings, debt }

class Transaction {
  final String id;
  final String userId;
  final TransactionType type;
  final double amount;
  final String category;
  final String description;
  final DateTime date;
  final String? receiptUrl;
  final bool isVoiceAdded;

  Transaction({
    required this.id,
    required this.userId,
    required this.type,
    required this.amount,
    required this.category,
    required this.description,
    required this.date,
    this.receiptUrl,
    this.isVoiceAdded = false,
  });

  factory Transaction.fromFirestore(DocumentSnapshot doc) {
    Map data = doc.data() as Map;
    return Transaction(
      id: doc.id,
      userId: data['userId'],
      type: _parseTransactionType(data['type']),
      amount: data['amount'].toDouble(),
      category: data['category'],
      description: data['description'],
      date: (data['date'] as Timestamp).toDate(),
      receiptUrl: data['receiptUrl'],
      isVoiceAdded: data['isVoiceAdded'] ?? false,
    );
  }

  static TransactionType _parseTransactionType(String type) {
    switch (type) {
      case 'income':
        return TransactionType.income;
      case 'savings':
        return TransactionType.savings;
      case 'debt':
        return TransactionType.debt;
      default:
        return TransactionType.expense;
    }
  }

  Map<String, dynamic> toMap() {
    return {
      'userId': userId,
      'type': type.toString().split('.').last,
      'amount': amount,
      'category': category,
      'description': description,
      'date': Timestamp.fromDate(date),
      'receiptUrl': receiptUrl,
      'isVoiceAdded': isVoiceAdded,
    };
  }
}