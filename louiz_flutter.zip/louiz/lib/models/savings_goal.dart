import 'package:cloud_firestore/cloud_firestore.dart';

class SavingsGoal {
  final String id;
  final String userId;
  final String name;
  final double currentAmount;
  final double targetAmount;
  final DateTime targetDate;

  SavingsGoal({
    required this.id,
    required this.userId,
    required this.name,
    required this.currentAmount,
    required this.targetAmount,
    required this.targetDate,
  });

  factory SavingsGoal.fromFirestore(DocumentSnapshot doc) {
    Map data = doc.data() as Map;
    return SavingsGoal(
      id: doc.id,
      userId: data['userId'],
      name: data['name'],
      currentAmount: data['currentAmount'].toDouble(),
      targetAmount: data['targetAmount'].toDouble(),
      targetDate: (data['targetDate'] as Timestamp).toDate(),
    );
  }

  Map<String, dynamic> toMap() {
    return {
      'userId': userId,
      'name': name,
      'currentAmount': currentAmount,
      'targetAmount': targetAmount,
      'targetDate': Timestamp.fromDate(targetDate),
    };
  }
}