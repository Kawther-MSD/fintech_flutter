import 'package:cloud_firestore/cloud_firestore.dart';

class Debt {
  final String id;
  final String userId;
  final String description;
  final double amount;
  final DateTime dueDate;
  final bool isOwed;
  final bool isPaid;

  Debt({
    required this.id,
    required this.userId,
    required this.description,
    required this.amount,
    required this.dueDate,
    this.isOwed = true,
    this.isPaid = false,
  });

  factory Debt.fromFirestore(DocumentSnapshot doc) {
    Map data = doc.data() as Map;
    return Debt(
      id: doc.id,
      userId: data['userId'],
      description: data['description'],
      amount: data['amount'].toDouble(),
      dueDate: (data['dueDate'] as Timestamp).toDate(),
      isOwed: data['isOwed'] ?? true,
      isPaid: data['isPaid'] ?? false,
    );
  }

  Map<String, dynamic> toMap() {
    return {
      'userId': userId,
      'description': description,
      'amount': amount,
      'dueDate': Timestamp.fromDate(dueDate),
      'isOwed': isOwed,
      'isPaid': isPaid,
    };
  }
}