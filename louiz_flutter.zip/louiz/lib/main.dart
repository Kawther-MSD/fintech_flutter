import 'package:flutter/material.dart';
import 'package:firebase_core/firebase_core.dart';
import 'package:louiz/controllers/auth_controller.dart';
import 'package:louiz/controllers/budget_controller.dart';
import 'package:louiz/controllers/debt_controller.dart';
import 'package:louiz/controllers/notification_controller.dart';
import 'package:louiz/controllers/savings_controller.dart';
import 'package:louiz/controllers/transaction_controller.dart';
import 'package:louiz/controllers/voice_controller.dart';
import 'package:louiz/utils/theme.dart';
import 'package:louiz/views/auth/login_screen.dart';
import 'package:louiz/views/auth/signup_screen.dart';
import 'package:louiz/utils/localization.dart';
import 'package:louiz/views/dashboard/dashboard_screen.dart';
import 'package:louiz/views/splash_screen.dart';
import 'package:provider/provider.dart';

void main() async {
  WidgetsFlutterBinding.ensureInitialized();
  
  // Initialize Firebase with error handling
  try {
    await Firebase.initializeApp(
      // options: DefaultFirebaseOptions.currentPlatform, // Uncomment if you have firebase_options.dart
    );
  } catch (e) {
    debugPrint('Firebase initialization error: $e');
  }
  
  runApp(
    MultiProvider(
      providers: [
        ChangeNotifierProvider(create: (_) => AuthController()),
        ChangeNotifierProvider(create: (_) => DebtController()),
        ChangeNotifierProvider(create: (_) => TransactionController()),
        ChangeNotifierProvider(create: (_) => BudgetController()),
        ChangeNotifierProvider(create: (_) => NotificationController()),
        ChangeNotifierProvider(create: (_) => SavingsController()),
        ChangeNotifierProvider(create: (_) => VoiceController()),
      ],
      child: const LouizApp(),
    ),
  );
}

class LouizApp extends StatelessWidget {
  const LouizApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Louiz',
      debugShowCheckedModeBanner: false,
      theme: AppTheme.lightTheme,
      darkTheme: AppTheme.darkTheme,
      themeMode: ThemeMode.system,
      
      // Localization setup
      supportedLocales: const [
        Locale('en', 'US'),
        Locale('fr', 'FR'), 
        Locale('ar', 'TN'),
      ],
      localizationsDelegates: AppLocalizations.localizationsDelegates,
      localeResolutionCallback: AppLocalizations.localeResolutionCallback,
      
      // Navigation setup
      initialRoute: '/splash',
      routes: {
        '/splash': (context) => const SplashScreen(),
        '/': (context) => Consumer<AuthController>(
          builder: (context, auth, _) {
            return auth.isAuthenticated 
                ? const DashboardScreen() 
                : const LoginScreen();
          },
        ),
        '/login': (context) => const LoginScreen(),
        '/signup': (context) => const SignupScreen(),
        '/dashboard': (context) => const DashboardScreen(),
      },
      
      // Global error handling
      builder: (context, child) {
        return GestureDetector(
          onTap: () {
            // Hide keyboard when tapping outside text fields
            FocusScope.of(context).requestFocus(FocusNode());
          },
          child: child,
        );
      },
    );
  }
}