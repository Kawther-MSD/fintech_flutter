import 'package:cloud_firestore/cloud_firestore.dart' hide Transaction;
import 'package:firebase_auth/firebase_auth.dart';
import 'package:louiz/models/transaction.dart' as model;
import 'package:louiz/models/budget.dart';
import 'package:louiz/models/savings_goal.dart';
import 'package:louiz/models/debt.dart';

class DatabaseService {
  final FirebaseFirestore _firestore = FirebaseFirestore.instance;

  // Transactions
  Future<List<model.Transaction>> getTransactions(String userId) async {
    final snapshot = await _firestore
        .collection('transactions')
        .where('userId', isEqualTo: userId)
        .orderBy('date', descending: true)
        .get();
    
    return snapshot.docs.map((doc) => model.Transaction.fromFirestore(doc)).toList();
  }

  Future<void> addTransaction(model.Transaction transaction) async {
    await _firestore
        .collection('transactions')
        .doc(transaction.id)
        .set(transaction.toMap());
  }

  Future<void> deleteTransaction(String transactionId) async {
    await _firestore.collection('transactions').doc(transactionId).delete();
  }

  // Budgets
  Future<Budget?> getCurrentBudget(String userId) async {
    final now = DateTime.now();
    final snapshot = await _firestore
        .collection('budgets')
        .where('userId', isEqualTo: userId)
        .where('startDate', isLessThanOrEqualTo: Timestamp.fromDate(now))
        .where('endDate', isGreaterThanOrEqualTo: Timestamp.fromDate(now))
        .limit(1)
        .get();
    
    return snapshot.docs.isEmpty ? null : Budget.fromFirestore(snapshot.docs.first);
  }

  Future<void> createBudget(Budget budget) async {
    await _firestore
        .collection('budgets')
        .doc(budget.id)
        .set(budget.toMap());
  }

  // Savings Goals
  Future<List<SavingsGoal>> getSavingsGoals(String userId) async {
    final snapshot = await _firestore
        .collection('savings_goals')
        .where('userId', isEqualTo: userId)
        .orderBy('targetDate')
        .get();
    
    return snapshot.docs.map((doc) => SavingsGoal.fromFirestore(doc)).toList();
  }

  Future<void> addSavingsGoal(SavingsGoal goal) async {
    await _firestore
        .collection('savings_goals')
        .doc(goal.id)
        .set(goal.toMap());
  }

  // Debts
  Future<List<Debt>> getDebts(String userId) async {
    final snapshot = await _firestore
        .collection('debts')
        .where('userId', isEqualTo: userId)
        .orderBy('dueDate')
        .get();
    
    return snapshot.docs.map((doc) => Debt.fromFirestore(doc)).toList();
  }

  Future<void> addDebt(Debt debt) async {
    await _firestore
        .collection('debts')
        .doc(debt.id)
        .set(debt.toMap());
  }

  Future<void> updateDebtStatus(String debtId, bool isPaid) async {
    await _firestore
        .collection('debts')
        .doc(debtId)
        .update({'isPaid': isPaid});
  }
}